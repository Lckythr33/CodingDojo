from django.apps import AppConfig


class PythonBeltConfig(AppConfig):
    name = 'Python_Belt'
